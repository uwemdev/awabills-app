class OnBoard {
  final String image;
  final String title;
  final String description;

  OnBoard({
    required this.image,
    required this.title,
    required this.description,
  });
}
